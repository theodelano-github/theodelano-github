import PySimpleGUI as sg
import pyautogui
import time

# --- Command Definitions ---
toolbox_commands = {
    "Basics": {
        "Print": ('print("Hello, World!")', "Outputs text to the screen.", "Use it to debug or show messages."),
        "Variable": ('x = 10', "Creates a variable named x.", "Stores the number 10."),
    },
    "Conditionals": {
        "If": ('if x > 10:\n    print("X is large")', "Checks if a condition is true.", "Executes code only if true."),
    },
    "Loops": {
        "For Loop": ('for i in range(5):\n    print(i)', "Repeats code a fixed number of times.", "Great for counting."),
        "While Loop": ('x = 0\nwhile x < 5:\n    print(x)\n    x += 1', "Repeats code while a condition is true.", "Useful for dynamic loops."),
    },
    "Functions": {
        "Define Function": ('def my_function():\n    print("Hello from a function!")', "Defines reusable code blocks.", "Called when needed."),
        "Function Call": ('my_function()', "Runs the previously defined function.", "Triggers its behavior."),
    }
}

# --- Globals ---
hovered_node_id = None
hover_popup = None
hover_popup_last_active = 0
hover_popup_grace_period = 1.0  # seconds


# --- Tree Builder ---
def get_toolbox_tree():
    data = sg.TreeData()
    for category, cmds in toolbox_commands.items():
        data.Insert("", category, category, [])
        for key in cmds:
            data.Insert(category, key, key, [])
    return data


def create_toolbox_element():
    return sg.Tree(
        data=get_toolbox_tree(),
        headings=[],
        auto_size_columns=True,
        col0_width=30,
        num_rows=20,
        key="-TOOLBOX_TREE-",
        show_expanded=True,
        enable_events=True,
        tooltip="Browse commands"
    )


def show_more_info(command_name):
    code, *_ = toolbox_commands[next(cat for cat in toolbox_commands if command_name in toolbox_commands[cat])][command_name]
    sg.popup_scrolled(code, title=f"Code for: {command_name}", size=(50, 10))


def open_hover_popup(desc1, desc2, command_name):
    global hover_popup
    if hover_popup:
        hover_popup.close()

    x, y = pyautogui.position()
    layout = [
        [sg.Text(desc1)],
        [sg.Text(desc2)],
        [sg.Push(), sg.Text("Show more", enable_events=True, key="-SHOW_MORE-",
                            font=('Helvetica', 9, 'underline'), text_color='blue')]
    ]
    hover_popup = sg.Window(
        '', layout, no_titlebar=True, keep_on_top=True,
        alpha_channel=0.95, margins=(10, 10), finalize=True,
        location=(x + 10, y + 10), grab_anywhere=False
    )
    hover_popup.CommandName = command_name

    # Bonus: Set hand cursor on "Show more"
    try:
        hover_popup["-SHOW_MORE-"].Widget.config(cursor="hand2")
    except Exception:
        pass


# --- Hover Popup Logic ---
def update_hover_popup(window):
    global hovered_node_id, hover_popup, hover_popup_last_active

    try:
        tree_elem = window["-TOOLBOX-"]
        widget = tree_elem.Widget
        mouse_x, mouse_y = pyautogui.position()
        tree_x, tree_y = widget.winfo_rootx(), widget.winfo_rooty()
        tree_w, tree_h = widget.winfo_width(), widget.winfo_height()

        mouse_inside_tree = (tree_x <= mouse_x <= tree_x + tree_w and
                             tree_y <= mouse_y <= tree_y + tree_h)

        popup_inside = False
        if hover_popup:
            try:
                popup_x = hover_popup.TKroot.winfo_rootx()
                popup_y = hover_popup.TKroot.winfo_rooty()
                popup_w = hover_popup.TKroot.winfo_width()
                popup_h = hover_popup.TKroot.winfo_height()

                buffer = 10
                popup_inside = (popup_x - buffer <= mouse_x <= popup_x + popup_w + buffer and
                                popup_y - buffer <= mouse_y <= popup_y + popup_h + buffer)
            except:
                pass

        # Stay alive if inside popup or tree
        if mouse_inside_tree or popup_inside:
            hover_popup_last_active = time.time()

        # Close if mouse left both for too long
        if hover_popup and not mouse_inside_tree and not popup_inside:
            if time.time() - hover_popup_last_active > hover_popup_grace_period:
                hover_popup.close()
                hover_popup = None
                hovered_node_id = None
                return

        # Only switch tooltip if not hovering popup
        if not popup_inside:
            node_id = widget.identify_row(mouse_y - tree_y)
            if node_id and node_id != hovered_node_id:
                node_text = widget.item(node_id, 'text')
                for category, cmds in toolbox_commands.items():
                    if node_text in cmds:
                        _, d1, d2 = cmds[node_text]
                        hovered_node_id = node_id
                        hover_popup_last_active = time.time()
                        open_hover_popup(d1, d2, node_text)
                        break

        # Popup events
        if hover_popup:
            event, _ = hover_popup.read(timeout=1)
            if event == "-SHOW_MORE-":
                popup_cmd = getattr(hover_popup, "CommandName", None)
                hover_popup.close()
                hover_popup = None
                if popup_cmd:
                    show_more_info(popup_cmd)
            elif event == sg.WIN_CLOSED:
                hover_popup = None

    except Exception:
        pass
