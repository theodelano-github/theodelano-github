import PySimpleGUI as sg
import pyautogui

def show_hover_popup(window, button_key, description, more_info_callback):
    # Create a tooltip-style popup window
    x, y = pyautogui.position()
    popup_layout = [
        [sg.Text(description[0], font=('Any', 10))],
        [sg.Text(description[1], font=('Any', 10))],
        [sg.Push(), sg.Text("Show more", enable_events=True, key="-SHOW_MORE-", font=('Any', 9, 'underline'), text_color='blue')]
    ]

    popup = sg.Window('', popup_layout, no_titlebar=True, keep_on_top=True, grab_anywhere=False,
                      finalize=True, location=(x + 10, y + 10), element_justification='left',
                      margins=(10, 10), alpha_channel=0.95)

    while True:
        event, _ = popup.read(timeout=100)
        if event == sg.WIN_CLOSED or not is_mouse_over_element(window, button_key):
            break
        if event == "-SHOW_MORE-":
            more_info_callback()
            break

    popup.close()

def is_mouse_over_element(window, key):
    # Check if mouse is over a specific element
    x, y = pyautogui.position()
    elem = window[key]
    elem_x, elem_y = window.TKroot.winfo_rootx() + elem.Widget.winfo_rootx(), window.TKroot.winfo_rooty() + elem.Widget.winfo_rooty()
    elem_w, elem_h = elem.Widget.winfo_width(), elem.Widget.winfo_height()
    return elem_x <= x <= elem_x + elem_w and elem_y <= y <= elem_y + elem_h

def show_more_info():
    sg.popup("Here is some more detailed information about the button.")

# Main window layout
layout = [
    [sg.Button("Hover Me", key="-HOVER_BTN-")],
    [sg.Text("", key="-OUTPUT-")]
]

window = sg.Window("Hover Example", layout, finalize=True)

hover_displayed = False

while True:
    event, values = window.read(timeout=100)

    if event == sg.WIN_CLOSED:
        break

    if is_mouse_over_element(window, "-HOVER_BTN-") and not hover_displayed:
        show_hover_popup(window, "-HOVER_BTN-", ["This button does something useful.", "Click it to take action."], show_more_info)
        hover_displayed = True
    elif not is_mouse_over_element(window, "-HOVER_BTN-"):
        hover_displayed = False

window.close()
